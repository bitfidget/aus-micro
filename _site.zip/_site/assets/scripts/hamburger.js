$(document).ready(function() {

	$('#hamburger-toggle').on('click touch', function(event) {
		event.preventDefault();
		$('#hamburger-container').toggleClass('active');
	});

});